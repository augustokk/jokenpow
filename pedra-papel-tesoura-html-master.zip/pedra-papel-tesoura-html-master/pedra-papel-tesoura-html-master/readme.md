### Jokempô ou Pedra, Papel e Tesoura
**[WIKIPEDIA]** (https://pt.wikipedia.org/wiki/Pedra,_papel_e_tesoura) - Pedra, papel e tesoura <br>
**[CODEPEN]** (https://codepen.io/kkkasio/pen/pGPJGY) - Demonstração

**Imagens**

![](jogoInicio.png)
![](jogoWin.png)
![](jogoLose.png)



**Sinta-se à vontade para contribuir!**
